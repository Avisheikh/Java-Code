/*
 java program to sum the elements of an array
 */
package gamestation;
import java.util.Scanner;
/**
 *
 * @author abishek
 */
public class sum {
    
    public static void main(String []args){
//    int[] array={10,20,30,40,50,60};
//    int sum=0;
//    //advance for loop
//    for (int num:array){
//    sum=sum+num;
//    }
//    System.out.println("Sum of array "+sum);

//user enter the array's elements
//Scanner scanner=new Scanner(System.in);
//int[]array=new int[10];
//int sum=0;
//System.out.println("Enter the elements"

//);
//for(int s = 0; s < 10 ;s++){
//array[s]=scanner.nextInt();}
//for(int num:array){
//sum=sum+num;
//}
//System.out.println("sum "+sum);

//finding the average of numbers using array
//int a[]={1,2,3,4,5,6};
//int ab=0;
////advance for loop
//for(int i=0;i<a.length;i++){
//ab=ab+2;

//  // Write your code here
//  int[]array={1,2,3,4,5};
//  int sum=0;
//  //advance for loop
//  for(int i: array){
//    sum += i;
//    System.out.println("array"+ sum);
//
//}
//System.out.println("sum"+a);
//parctise question 1.




}
    
    }

