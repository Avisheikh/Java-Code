/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package workshop1;

/**
 *
 * @author abishek
 */
import java.io.*;
import java.util.*;
public class workshop2 {
    public void input()throws IOException{
    BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
    br.readLine();
    
    }
    public static void main(String []args)throws IOException{
        workshop2 w=new workshop2();
    w.input();
    }
}
