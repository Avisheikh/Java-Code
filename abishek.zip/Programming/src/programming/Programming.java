
public class Programming {

    public Programming(){
    System.out.println("I love programming");
    }
    public Programming(String x){
    System.out.println("I love"+x);
    }
    public static void main(String[] args) {
        Programming obj=new Programming();
        Programming obj1=new Programming("you");
    }
    
}
