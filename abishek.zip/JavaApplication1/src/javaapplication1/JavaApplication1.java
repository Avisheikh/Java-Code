/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication1;

/**
 *
 * @author abishek
 */
public class JavaApplication1 {

    /**
     * @param args the command line arguments
     */
    //instance variables
double length, width, height;
	
//defining constructor(s)
___s_____(double ______, double ______, double ______){
	this.length = ______;
	this.width = ______;
	this.height = ______;
}

//guess what shape this represents
______ (double ______){
	length = ______;
	width = ______;
	height = ______;
}
}
