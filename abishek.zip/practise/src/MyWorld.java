
public class MyWorld {
    MyWorld(){
    
    }
  public static void main (String[] args){
       MyWorld Myworld=new MyWorld();
       for(int i=0; i<5;i++){
       
       }
       System.out.println("listen to my word");
       
   
   
   }
   
}
