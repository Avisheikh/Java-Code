public class Abishek{
    double length , width , height;
    Abishek(double length, double width , double height){
        this.height=height;
        this.length=length;
        this.width=width;
    }
    public static void main(String[] args){
        Abishek laptop= new Abishek(41.12,24.31,21.23); 
        System.out.println("laptop Price");
    }
    }
    
    
