
import java.util.Scanner;

public class Workshop{
public static void main(String[] args){
    System.out.println("enter the number");
    Scanner sc = new Scanner(System.in);
    int fristNumber=sc.nextInt();
    System.out.println("enter the number again");
    int firstNumber = 0;
    int secondNumber = 0;
    int sum=firstNumber+secondNumber;
    syst
    
}
}
 
     
