/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myworld;

/**
 *
 * @author abishek
 */
public class Myworld {

  Myworld(){
  for(int i=0; i<5;i++){
      System.out.println("Listening to my music");
  }
  
  }
    public static void main(String[] args) {
      Myworld MyWorld1=new Myworld();
    }
    
}
